- [Theme Settings](https://github.com/1ForeverHD/TopbarPlus/blob/main/src/Icon/Themes/Default.lua)
- [Model](https://www.roblox.com/library/6311707237/TopbarPlus)
- [Playground](https://www.roblox.com/games/6199274521/TopbarPlus-Playground)
- [Discussion](https://devforum.roblox.com/t/topbarplus-v2-construct-dynamic-and-intuitive-topbar-icons/1017485)
- [Repository](https://github.com/1ForeverHD/TopbarPlus)
- [Roblox-TS Port](https://github.com/grilme99/TopbarPlus) by [grilme99](https://twitter.com/grilme99)
- [YouTube Video](https://youtu.be/c_emUAWTRKg) by [Inctus](https://www.youtube.com/c/Inctus)

-------------------------------------

If you would like to submit a resource (such as a video tutorial, port, etc), please see [contributing](https://1foreverhd.github.io/TopbarPlus/contributing/).
